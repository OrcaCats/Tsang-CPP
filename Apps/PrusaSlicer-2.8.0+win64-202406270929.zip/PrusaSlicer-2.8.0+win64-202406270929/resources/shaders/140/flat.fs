#version 140

uniform vec4 uniform_color;

out vec4 out_color;

void main()
{
    out_color = uniform_color;
}
